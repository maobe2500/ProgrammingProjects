class Ingredient(object):

    #en simpel klass som innehåller namn och pris på en ingrediens

    def __init__(self, name, price):
        self.name = name
        self.price = price
